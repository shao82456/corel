#!/bin/sh
exec scala "$0" "$@"
!#
println("你好")
