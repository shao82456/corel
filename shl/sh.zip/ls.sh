ls -l $1
