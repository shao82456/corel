#!/usr/bin/env bash
echo $(pwd)/$1
