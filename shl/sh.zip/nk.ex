#!/usr/bin/expect 
set auth_code [lindex $argv 0]
set password [lindex $argv 1]
set target_host [lindex $argv 2]
set timeout 30
spawn ssh shaofengfeng@relay.afpai.com
expect {
    "*(yes/no)" {send "yes\n";exp_continue}
    "Verification code:" {send "$auth_code\n";exp_continue}
    "*assword:" {send "$password\n";exp_continue}
	"Welcom*" {send "ssh homework@$target_host\n";exp_continue}
	"Last login:*" {send "source shaofengfeng/.bashrc\n";}
}
interact 
