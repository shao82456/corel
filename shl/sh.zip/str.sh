#!/bin/bash
str1="hello"
str2="world"
str="$str1""$str2"

echo "$str"
